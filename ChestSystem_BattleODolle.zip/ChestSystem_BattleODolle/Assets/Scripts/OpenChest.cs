using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class OpenChest : MonoBehaviour
{
    public GameObject btnCommonChest;
    public GameObject btnSmallChest;
    public GameObject btnLegendaryChest;
    public GameObject btnEpicChest;
    public GameObject btnWatchAd;

    int can_Open_commonChest;
    int can_Open_smallChest;
    int can_Open_legendaryChest;
    int can_Open_epicChest;

    public int cardNum;
    public string chestType;
    bool watchedAd = false;
    int rnd_watchedAd;
    int gold;
    int[] unturnedCards=new int[4];
    //int cardIndex;

    public GameObject[] cardsShow;


    void Start()
    {
        
        can_Open_commonChest = 1;
        can_Open_smallChest = 1;
        can_Open_legendaryChest = 1;
        can_Open_epicChest = 1;

    }

    
    void Update()
    {
        if (can_Open_commonChest>=1)
        {
            btnCommonChest.SetActive(true);
        }
        else
        {
            btnCommonChest.SetActive(false);
        }

        if (can_Open_smallChest >= 1)
        {
            btnSmallChest.SetActive(true);
        }
        else
        {
            btnSmallChest.SetActive(false);
        }

        if (can_Open_legendaryChest >= 1)
        {
            btnLegendaryChest.SetActive(true);
        }
        else
        {
            btnLegendaryChest.SetActive(false);
        }

        if (can_Open_epicChest >= 1)
        {
            btnEpicChest.SetActive(true);
        }
        else
        {
            btnEpicChest.SetActive(false);
        }


    }
    public void OnOpenCommonChestClicked()
    {
       
        can_Open_commonChest = can_Open_commonChest - 1;
        cardNum = 8;
        for (int r = 0; r < 4; r++)
        {
            unturnedCards[r] = Random.Range(1, 9);
        }
        Chest commonChest = new Chest(cardNum);
        
        for (int i = 0; i < cardNum; i++)
        {
           cardsShow[i].SetActive(true);
           cardsShow[i].GetComponentInChildren<Text>().text = commonChest.currentCards[i];
            cardsShow[unturnedCards[0]].GetComponent<Image>().color = Color.black;
            cardsShow[unturnedCards[1]].GetComponent<Image>().color = Color.black;
            cardsShow[unturnedCards[2]].GetComponent<Image>().color = Color.black;

            if (commonChest.currentCards[i]== "WatchAd")
            {
                btnWatchAd.SetActive(true);
            }
        }
        
        
        
    }
    public void OnOpenSmallChestClicked()
    {
        can_Open_smallChest = can_Open_smallChest - 1;
        cardNum = 2;
        Chest smallChest = new Chest(cardNum);

        for (int i = 0; i < cardNum; i++)
        {
            cardsShow[i].SetActive(true);
            cardsShow[i].GetComponentInChildren<Text>().text = smallChest.currentCards[i];
            if (smallChest.currentCards[i] == "WatchAd")
            {
                btnWatchAd.SetActive(true);
            }
        }

    }
    public void OnOpenLegendaryChestClicked()
    {
        can_Open_legendaryChest = can_Open_legendaryChest - 1;
        cardNum = 18;
        chestType = "Legendary";
        Chest LegendaryChest = new Chest(cardNum,chestType);

        for (int i = 0; i < cardNum; i++)
        {
            cardsShow[i].SetActive(true);
            cardsShow[i].GetComponentInChildren<Text>().text = LegendaryChest.currentCards[i];
        }

    }
    public void OnOpenEpicChestClicked()
    {
        can_Open_epicChest = can_Open_epicChest - 1;
        cardNum = 12;
        chestType = "Epic";
        Chest epicChest = new Chest(cardNum,chestType);

        for (int i = 0; i < cardNum; i++)
        {
            cardsShow[i].SetActive(true);
            cardsShow[i].GetComponentInChildren<Text>().text = epicChest.currentCards[i];
        }

    }
    public void OnWatchAdClicked()
    {
        watchedAd = true;
        rnd_watchedAd= Random.Range(1, 11);
        if (rnd_watchedAd==1)
        {
            can_Open_commonChest = can_Open_commonChest + 1;
            can_Open_smallChest = can_Open_smallChest + 1;
        }
        else if(rnd_watchedAd > 1 && rnd_watchedAd <5)
        {
            gold = gold + 10;

        }
        else if (rnd_watchedAd>=5)
        {
            //give hero card
        }

    }
    public void OnCardsClicked()
    {
        EventSystem.current.currentSelectedGameObject.GetComponent<Image>().color = Color.white;
       
    }

}
