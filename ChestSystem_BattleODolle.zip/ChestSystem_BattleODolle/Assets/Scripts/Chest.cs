using System.Collections;
using System.Collections.Generic;

using UnityEngine;



public class Chest 
{
    private string[] cardTypes = { "HeroCards", "Gold", "Diamond", "Token", "WatchAd" };
    private string[] premium_cardTypes = { "HeroCards", "Gold", "Diamond", "Token" };
    private string[] heroTypes = { "Nurse", "Soldier", "Headsman" };
    public string[] currentCards = new string[19];

    int cardIndex;
    int rnd;
    
   
    public string[] CardTypes
    {
        get
        {
            return cardTypes;
        }
        set
        {
            cardTypes = value;
        }
    }
    public string[] Premium_CardTypes
    {
        get
        {
            return premium_cardTypes;
        }
        set
        {
            premium_cardTypes = value;
        }
    }
    public string[] HeroTypes
    {
        get
        {
            return heroTypes;
        }
        set
        {
            heroTypes = value;
        }
    }

    public Chest(int cardNum)
    {

        for (int i = 0; i <= cardNum; i++)
        {
            

            rnd = Random.Range(1, 11);
            //Debug.Log(i.ToString()+"  "+rnd.ToString());

            if (rnd <= 3)
            {
                cardIndex = 0;
            }
            else if (rnd == 4 || rnd == 5)
            {
                cardIndex = 1;
            }
            else if (rnd == 6)
            {
                cardIndex = 2;
            }
            else if (rnd == 7)
            {
                cardIndex = 3;
            }
            else if (rnd >= 8)
            {
                cardIndex = 4;
            }

            this.currentCards[i] = CardTypes[cardIndex];
        }
        
    }
    public Chest(int cardNum,string chestType)
    {

        for (int i = 0; i <= cardNum; i++)
        {


            rnd = Random.Range(1, 11);
            //Debug.Log(i.ToString()+"  "+rnd.ToString());

            if (rnd <= 3)
            {
                cardIndex = 0;
            }
            else if (rnd == 4 || rnd == 5)
            {
                cardIndex = 1;
            }
            else if (rnd >= 6)
            {
                cardIndex = 2;
            }
            
            this.currentCards[i] = Premium_CardTypes[cardIndex];
        }

    }

}
